import mysql.connector
import csv
from tabulate import tabulate
# from datetime import datetime

# Koneksi ke database
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="herza",
    database="SysAdminLibrary"
)
cursor = conn.cursor()
# cursor() adalah metode yang dipanggil dari objek conn untuk membuat objek cursor
# conn adalah objek koneksi yang dibuat dengan mysql.connector.connect(), yang digunakan untuk berkomunikasi dengan database

# Kredensial admin untuk autentikasi
admin_credentials = {"admin": "passwd123"}

def authenticate():
    username = input("Enter username admin: ")
    password = input("Enter password: ")
    return admin_credentials.get(username) == password

# Menampilkan menu utama
def display_menu():
    print("\n--- System Administration Library ---")
    print("1.  Adding New User(Borrower)")
    print("2.  Displaying User(borrower)")
    print("3.  Adding New Books")
    print("4.  Displaying Book List")
    print("5.  Borrowing Books")
    print("6.  Returning Books")
    print("7.  Extending Book Loan")
    print("8.  View Transaction History")
    print("9.  Print History and Save to CSV")
    print("10. Delete Borrowing History")
    print("11. Exit")

# Mendaftarkan pengguna baru
def register_user():
    name = input("Enter Name: ")  # Meminta input nama pengguna
    nik = input("Enter NIK: ")  # Meminta input NIK pengguna
    address = input("Enter Address: ")  # Meminta input alamat pengguna
    phone = input("Enter Phone Number: ")  # Meminta input nomor telepon pengguna
    
    # Cek apakah NIK sudah ada di database
    cursor.execute("SELECT COUNT(*) FROM users WHERE nik = %s", (nik,))
    result = cursor.fetchone()

    if result[0] > 0:  # Jika NIK sudah ada
        print("Sorry, your NIK is already registered. Please use another NIK.")
        return  # Kembali ke menu awal tanpa menyimpan data

    # Jika NIK belum ada, lanjutkan pendaftaran
    cursor.execute("INSERT INTO users (name, nik, address, phone) VALUES (%s, %s, %s, %s)", 
                   (name, nik, address, phone))
    conn.commit()  # Menyimpan perubahan ke database
    print("User successfully registered.")  # Menampilkan pesan sukses

# Menambahkan buku baru
def add_books():
    # show_books()  # Menampilkan daftar buku yang ada
    book_id = input("Enter Book ID: ")  # Meminta input ID buku
    title = input("Enter Book Title: ")  # Meminta input judul buku
    status = input("Enter Book Status (available/not available): ").strip().lower()  # Meminta input status buku
    
    # Validasi status buku
    if status not in ["available", "not available"]:
        print("Invalid book status. Use 'available' or 'not available'.")
        return
    
    cursor.execute("INSERT INTO books (book_id, title, status) VALUES (%s, %s, %s)", (book_id, title, status))  # Menyimpan data buku ke database
    conn.commit()  # Menyimpan perubahan ke database
    print("Book successfully added.")  # Menampilkan pesan sukses

# Menampilkan daftar buku yang tersedia
def show_books(): 
    cursor.execute("SELECT * FROM books") # Mengambil semua data buku dari tabel books
    books = cursor.fetchall() # Mengambil hasil dari query di atas dan menyimpannya dalam variabel books
    
    if not books:
        print("There are no books in the database.")
        return  # Keluar dari fungsi jika tidak ada data
    
    headers = ["ID", "Title", "Status"]
    print("\nList of books:")
    print(tabulate(books, headers=headers, tablefmt="grid"))

# Menampilkan daftar pengguna
def show_users():
    cursor.execute("SELECT * FROM users")  # Mengambil ID dan nama pengguna dari tabel users
    users = cursor.fetchall() # Mengambil hasil dari query di atas dan menyimpannya dalam variabel users
    
    if not users:
        print("There are no users in the database.")
        return  # Keluar dari fungsi jika tidak ada data
    
    headers = ["ID", "Name", "NIK", "Address", "Phone"]
    print("\nList of Users:")
    print(tabulate(users, headers=headers, tablefmt="grid"))
    
# Meminjam buku
def borrow_book():
    show_users() # Menampilkan daftar pengguna sebelum memilih
    show_books() # Menampilkan daftar buku sebelum memilih
    

    user_id = input("Enter ID User: ") # Meminta input ID pengguna
    # Mengecek apakah pengguna memiliki peminjaman yang belum dikembalikan
    cursor.execute("SELECT * FROM transactions WHERE user_id = %s AND return_date IS NULL", (user_id,))
    active_loan = cursor.fetchone() # Mengambil hasil dari query di atas dan menyimpannya dalam variabel active_loan
    
    if active_loan: # Jika pengguna masih memiliki pinjaman yang belum dikembalikan
        print("Users can only borrow one book at a time. Please return the book first.")
        return
    
    book_id = input("Enter the ID of the book you want to borrow: ") # Meminta input ID buku
    cursor.execute("SELECT status FROM books WHERE book_id = %s", (book_id,))  # Mengecek status buku
    book = cursor.fetchone() # Mengambil hasil dari query di atas dan menyimpannya dalam variabel book
    
    if book and book[0] == "available": # Jika buku tersedia
        # Memasukkan data peminjaman ke tabel transactions
        cursor.execute("INSERT INTO transactions (user_id, book_id, borrow_date, due_date) VALUES (%s, %s, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 3 DAY))", (user_id, book_id))
        # Mengubah status buku menjadi tidak tersedia
        cursor.execute("UPDATE books SET status = 'not available' WHERE book_id = %s", (book_id,))
        # Menambahkan riwayat peminjaman
        cursor.execute("INSERT INTO history (user_id, book_id, action, action_date) VALUES (%s, %s, 'borrow', CURDATE())", (user_id, book_id))
        conn.commit() # Menyimpan perubahan ke database
        print("Book successfully borrowed.") # Menampilkan pesan sukses
    else:
        print("Books are not available for borrowing.") # Jika tidak tersedia, tampilkan pesan kesalahan

# Mengembalikan buku
def return_book():
    show_books()
    show_users()
    user_id = input("Enter ID User: ") # Meminta input ID pengguna
    book_id = input("Enter the Book ID you want to return: ") # Meminta input ID buku
    # Mengecek apakah ada transaksi peminjaman yang belum dikembalikan
    cursor.execute("SELECT * FROM transactions WHERE user_id = %s AND book_id = %s AND return_date IS NULL", (user_id, book_id))
    transaction = cursor.fetchone() # Mengambil hasil dari query di atas dan menyimpannya dalam variabel transaction
    
    if transaction: # Jika ada transaksi peminjaman yang cocok
        # Menetapkan tanggal pengembalian
        cursor.execute("UPDATE transactions SET return_date = CURDATE() WHERE user_id = %s AND book_id = %s", (user_id, book_id))
        # Mengubah status buku menjadi tersedia
        cursor.execute("UPDATE books SET status = 'available' WHERE book_id = %s", (book_id,))
        # Menambahkan ke riwayat peminjaman
        cursor.execute("INSERT INTO history (user_id, book_id, action, action_date) VALUES (%s, %s, 'return', CURDATE())", (user_id, book_id))
        conn.commit() # Menyimpan perubahan ke database
        print("Book successfully returned.") # Menampilkan pesan sukses
    else:
        print("There is no loan suitable for return.") # Jika tidak ditemukan, tampilkan pesan kesalahan

# Memperpanjang peminjaman buku
def extend_borrowing():
    show_books()
    show_users()
    user_id = input("Enter ID User: ") # Meminta input dari pengguna untuk memasukkan ID User
    book_id = input("Enter the Book ID you want to extend: ") # Meminta input dari pengguna untuk memasukkan ID Buku yang ingin diperpanjang
    # Mengeksekusi query untuk mencari transaksi peminjaman berdasarkan user_id dan book_id
    # yang belum dikembalikan (return_date IS NULL)
    cursor.execute("SELECT * FROM transactions WHERE user_id = %s AND book_id = %s AND return_date IS NULL", (user_id, book_id))
    transaction = cursor.fetchone() # Mengambil hasil dari query di atas dan menyimpannya dalam variabel transaction
    
    if transaction: # Mengecek apakah transaksi peminjaman ditemukan
        # Jika transaksi ditemukan, memperpanjang tanggal jatuh tempo (due_date) dengan menambah 3 hari
        cursor.execute("UPDATE transactions SET due_date = DATE_ADD(due_date, INTERVAL 3 DAY) WHERE user_id = %s AND book_id = %s", (user_id, book_id))
         # Mencatat aksi perpanjangan peminjaman ke tabel history dengan tanggal hari ini (CURDATE())
        cursor.execute("INSERT INTO history (user_id, book_id, action, action_date) VALUES (%s, %s, 'extend', CURDATE())", (user_id, book_id))
        conn.commit() # Menyimpan perubahan ke database
        print("Book loan successfully extended.") # Menampilkan pesan sukses
    else:
        print("There are no suitable loans to extend.") # Jika tidak ditemukan, tampilkan pesan kesalahan

# Fungsi untuk menampilkan riwayat peminjaman buku
def transaction_history():
    cursor = conn.cursor(dictionary=True) # Membuat objek cursor dengan dictionary=True
    cursor.execute("SELECT t.transaction_id, t.book_id, u.nik, u.name, t.borrow_date, t.due_date, t.return_date "
                   "FROM transactions t "
                   "JOIN users u ON t.user_id = u.user_id") # Mengambil semua data buku dari tabel books
    transactions = cursor.fetchall() # Mengambil hasil dari query di atas dan menyimpannya dalam variabel books
    formatted_transactions = []
    for trans in transactions:
        borrow_date_str = trans["borrow_date"].strftime("%Y-%m-%d %H:%M:%S")
        due_date_str = trans["due_date"].strftime("%Y-%m-%d %H:%M:%S")
        return_date_str = trans["return_date"].strftime("%Y-%m-%d %H:%M:%S") if trans["return_date"] else "Belum dikembalikan"
            
        formatted_transactions.append([
            trans['transaction_id'], trans['book_id'], trans['nik'], trans['name'], 
            borrow_date_str, due_date_str, return_date_str
        ])

    # Menampilkan riwayat transaksi dalam format tabel
    headers = ["Transaction ID", "Book ID", "NIK", "Name", "Borrrow Date", "Return Limit", "Return Date"]
    print("\nTransaction History:")
    print(tabulate(formatted_transactions, headers=headers, tablefmt="grid"))

# Mengekspor riwayat peminjaman ke file CSV
def export_history():
    # Mengambil data riwayat peminjaman dengan menghubungkan tabel history, users, dan books
    cursor.execute("SELECT h.user_id, u.name, h.book_id, b.title, h.action, h.action_date FROM history h JOIN users u ON h.user_id = u.user_id JOIN books b ON h.book_id = b.book_id")
    history = cursor.fetchall() # Mengambil hasil dari query di atas dan menyimpannya dalam variabel history
    if history: # Jika ada data
        with open("history.csv", "w", newline="") as file: # Membuka file CSV untuk ditulis
            writer = csv.writer(file) # Membuat writer CSV
            writer.writerow(["User ID", "User Name", "Book ID", "Book Name", "Action", "Action Date"]) # Menulis header kolom
            writer.writerows(history) # Menulis data ke dalam file CSV
        print("Loan history successfully saved in history.csv") # Menampilkan pesan sukses
    else:
        print("No borrowing history to export.") # Jika tidak ada data, tampilkan pesan kesalahan

# Menghapus semua riwayat peminjaman
def delete_history():
    cursor.execute("DELETE FROM history") # Menghapus semua data dari tabel history
    conn.commit() # Menyimpan perubahan ke database
    print("All borrowing history has been deleted.") # Menampilkan pesan konfirmasi


# Loop utama program

if not authenticate():
    print("Login failed. Program stopped.")
    exit()

while True:
    display_menu()
    choice = input("Main Menu: ")
    if choice == "1":
        register_user()
    elif choice == "2":
        show_users()
    elif choice == "3":
        add_books()
    elif choice == "4":
        show_books()
    elif choice == "5":
        borrow_book()
    elif choice == "6":
        return_book()
    elif choice == "7":
        extend_borrowing()
    elif choice == "8":
        transaction_history()
    elif choice == "9":
        export_history()
    elif choice == "10":
        delete_history()
    elif choice == "11":
        print("Exit From Program.")
        break
    else:
        print("Input is not valid, Please Try Again.")

cursor.close() # Menutup objek cursor yang digunakan untuk menjalankan perintah SQL pada database.
conn.close() # Menutup koneksi database yang sebelumnya dibuka dengan conn = mysql.connector.connect()
 
