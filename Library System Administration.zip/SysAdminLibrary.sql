-- Create Database
-- Membuat database dengan nama 'SysAdminLibrary' jika belum ada
CREATE DATABASE IF NOT EXISTS SysAdminLibrary;

-- Activate the database
-- Menggunakan database 'SysAdminLibrary'
USE SysAdminLibrary;

-- Create Table: books
-- Membuat tabel 'books' untuk menyimpan data buku
CREATE TABLE IF NOT EXISTS books (
    book_id VARCHAR(10) NOT NULL UNIQUE PRIMARY KEY, -- ID unik untuk setiap buku
    title VARCHAR(100) NOT NULL, -- Judul buku
    status ENUM('tersedia', 'tidak tersedia') DEFAULT 'tersedia' -- Status ketersediaan buku
);

-- Create Table: users
-- Membuat tabel 'users' untuk menyimpan data pengguna
CREATE TABLE IF NOT EXISTS users (
    user_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, -- ID unik untuk setiap pengguna, bertambah otomatis
    name VARCHAR(100) NOT NULL, -- Nama pengguna
    nik VARCHAR(50) NOT NULL UNIQUE, -- Nomor identitas unik pengguna
    address TEXT NOT NULL, -- Alamat pengguna
    phone VARCHAR(20) NOT NULL -- Nomor telepon pengguna
);

-- Create Table: transactions
-- Membuat tabel 'transactions' untuk menyimpan data transaksi peminjaman buku
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, -- ID unik untuk setiap transaksi
    user_id INT NOT NULL, -- ID pengguna yang meminjam buku
    book_id VARCHAR(10) NOT NULL, -- ID buku yang dipinjam
    borrow_date DATE, -- Tanggal peminjaman
    due_date DATE, -- Tanggal jatuh tempo pengembalian
    return_date DATE, -- Tanggal pengembalian buku
    CONSTRAINT fk_transactions_user FOREIGN KEY (user_id) REFERENCES users(user_id) 
        ON DELETE CASCADE ON UPDATE CASCADE, -- Menghapus atau memperbarui transaksi jika pengguna dihapus atau diperbarui
    CONSTRAINT fk_transactions_book FOREIGN KEY (book_id) REFERENCES books(book_id) 
        ON DELETE CASCADE ON UPDATE CASCADE -- Menghapus atau memperbarui transaksi jika buku dihapus atau diperbarui
);

-- Create Table: history
-- Membuat tabel 'history' untuk menyimpan riwayat peminjaman dan pengembalian
CREATE TABLE IF NOT EXISTS history (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, -- ID unik untuk setiap riwayat
    user_id INT NOT NULL, -- ID pengguna
    book_id VARCHAR(10) NOT NULL, -- ID buku
    action VARCHAR(10) NOT NULL, -- Jenis aksi (misalnya 'pinjam' atau 'kembali')
    action_date DATE NOT NULL, -- Tanggal aksi dilakukan
    FOREIGN KEY (user_id) REFERENCES users(user_id), -- Relasi dengan tabel users
    FOREIGN KEY (book_id) REFERENCES books(book_id) -- Relasi dengan tabel books
);

-- Select Data
-- Menampilkan semua data dari tabel transactions
SELECT * FROM books;
-- Menampilkan semua data dari tabel history
SELECT * FROM history;



